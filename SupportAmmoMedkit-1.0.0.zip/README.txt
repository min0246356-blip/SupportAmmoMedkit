# Support Ammo Box Medical Supply

This VU mod makes the original Battlefield 3 Support Ammo Box also heal nearby soldiers.

## What was found in the original BF3 EBX data

The original Ammo Box already contains:

- `SupplyData`
- `Healing::SupplyUnitSphereData`

But its healing values are disabled:

- `supplyIncSpeed = 0`
- `infiniteCapacity = false`
- `supplyPointsCapacity = 0`

The original Medic Box uses:

- `supplyIncSpeed = 12.0`
- `infiniteCapacity = true`
- `supplyPointsCapacity = 1.0`
- `radius = 3.5`

The mod copies those Medic Box healing settings onto the original Ammo Box.

## Installation

Put this folder into:

`Server/Admin/Mods/`

Then add the mod folder name to:

`Server/Admin/ModList.txt`

Example:

`SupportAmmoMedkit`

## Important

This is a shared data modification. Do not move the script to `ext/server`.

Both server and clients need to receive the same data modification to avoid data mismatch problems.

## Result

Support Ammo Box:

- Keeps its normal ammunition resupply.
- Also restores health like the original Medic Box.
- Uses the original Ammo Box model and projectile.
- Does not replace the Medic Box.
