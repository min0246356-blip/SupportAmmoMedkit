-- Support Ammo Box + Medical Healing
-- Battlefield 3 / Venice Unleashed
--
-- Makes the original Support Ammo Box also provide the same healing
-- effect as the original Medic Box.
--
-- Original Ammo Box:
--   Healing.supplyIncSpeed = 0
--   Healing.infiniteCapacity = false
--   Healing.supplyPointsCapacity = 0
--
-- Original Medic Box:
--   Healing.supplyIncSpeed = 12
--   Healing.infiniteCapacity = true
--   Healing.supplyPointsCapacity = 1

local AMMOBOX_PARTITION = Guid('04CD683B-1F1B-11E0-BBD1-F7235575FD24')
local AMMOBOX_PROJECTILE = Guid('4AE515CE-846D-6070-5F56-1285B7E8E187')

local function EnableHealingOnAmmoBox(instance)
    if instance == nil or not instance:Is('SupplySphereEntityData') then
        return
    end

    local ammoBox = SupplySphereEntityData(instance)
    ammoBox:MakeWritable()

    -- Clone the structure before changing it.
    -- This avoids modifying a temporary structure value.
    local supplyData = ammoBox.supplyData:Clone()
    local healing = supplyData.healing:Clone()

    -- Match the original Medic Box healing behavior.
    healing.radius = 3.5
    healing.supplyIncSpeed = 12.0
    healing.infiniteCapacity = true
    healing.supplyPointsRefillSpeed = 0.0
    healing.supplyPointsCapacity = 1.0

    supplyData.healing = healing
    ammoBox.supplyData = supplyData

    print('[SupportAmmoMedkit] Ammo Box healing enabled')
    print('[SupportAmmoMedkit] Healing speed: 12.0')
    print('[SupportAmmoMedkit] Healing radius: 3.5')
end

-- The modification is shared so both server and clients receive the
-- same Frostbite data modification.
Events:Subscribe('Partition:Loaded', function(partition)
    if partition.guid ~= AMMOBOX_PARTITION then
        return
    end

    local instance = partition:FindInstance(AMMOBOX_PROJECTILE)

    if instance ~= nil then
        EnableHealingOnAmmoBox(instance)
    else
        print('[SupportAmmoMedkit] ERROR: Ammo Box projectile instance not found')
    end
end)

print('[SupportAmmoMedkit] Loaded')
